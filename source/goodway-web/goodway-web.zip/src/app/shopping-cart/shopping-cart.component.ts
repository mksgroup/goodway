import { ShoppingCartService } from './../shopping-cart.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { } from '@types/googlemaps';


@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  cart$;
  title: string = 'My first AGM project';
  lat: number = 51.678418;
  lng: number = 7.809007;

  constructor(private shoppingCartService: ShoppingCartService) { }

  async ngOnInit() {
    this.cart$ = await this.shoppingCartService.getCart();

    
  }

  clearCart() { 
    this.shoppingCartService.clearCart();
  }
}
