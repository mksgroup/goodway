export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCJB-M1LfU314Msdxx55Pf4YjwK_n8iwbM",
    authDomain: "book-20853.firebaseapp.com",
    databaseURL: "https://book-20853.firebaseio.com",
    projectId: "book-20853",
    storageBucket: "book-20853.appspot.com",
    messagingSenderId: "248368315271"    
  }
};
